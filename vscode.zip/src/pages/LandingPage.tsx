import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Services from '../components/Services';
import Packages from '../components/Packages';
import About from '../components/About';
import Testimonials from '../components/Testimonials';
import Booking from '../components/Booking';
import Footer from '../components/Footer';

export default function LandingPage() {
  return (
    <>
      <Navbar />
      <Hero />
      <Services />
      <Packages />
      <About />
      <Testimonials />
      <Booking />
      <Footer />
    </>
  );
}
