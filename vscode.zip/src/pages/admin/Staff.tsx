import { useState, useEffect } from 'react';
import { useStaffStore, type Employee } from '../../store/staffStore';
import { Plus, X, Edit2, Trash2, Phone, Mail, Clock, DollarSign, UserCog } from 'lucide-react';
import './Staff.css';

const emptyForm: Omit<Employee, 'id'> = {
  name: '', role: '', phone: '', email: '', commissionPct: 0, schedule: '', active: true,
};

export default function Staff() {
  const { employees, fetchStaff, addEmployee, updateEmployee, deleteEmployee } = useStaffStore();

  useEffect(() => { fetchStaff(); }, [fetchStaff]);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);

  const openCreate = () => { setEditingId(null); setForm(emptyForm); setShowModal(true); };
  const openEdit = (e: Employee) => {
    setEditingId(e.id);
    setForm({ name: e.name, role: e.role, phone: e.phone, email: e.email, commissionPct: e.commissionPct, schedule: e.schedule, active: e.active });
    setShowModal(true);
  };

  const handleSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (editingId) await updateEmployee(editingId, form);
    else await addEmployee(form);
    setShowModal(false);
  };

  return (
    <div className="staff">
      <div className="clients__header">
        <div>
          <h1 className="clients__title">Gestión de Empleadas</h1>
          <p className="clients__subtitle">{employees.filter(e => e.active).length} empleadas activas</p>
        </div>
        <button className="appts__add-btn" onClick={openCreate} id="btn-new-employee"><Plus size={18} /> Nueva Empleada</button>
      </div>

      <div className="staff__grid">
        {employees.map((e) => (
          <div className={`staff-card ${!e.active ? 'staff-card--inactive' : ''}`} key={e.id}>
            <div className="staff-card__avatar">
              {e.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
            </div>
            <h3>{e.name}</h3>
            <span className="staff-card__role">{e.role}</span>

            <div className="staff-card__details">
              <div><Phone size={13} /> {e.phone}</div>
              <div><Mail size={13} /> {e.email}</div>
              <div><Clock size={13} /> {e.schedule}</div>
              <div><DollarSign size={13} /> Comisión: <strong>{e.commissionPct}%</strong></div>
            </div>

            <div className="staff-card__actions">
              <button className="appt-card__action-btn" onClick={() => openEdit(e)}><Edit2 size={15} /></button>
              <button className="appt-card__action-btn" onClick={() => updateEmployee(e.id, { active: !e.active })}>
                <UserCog size={15} />
              </button>
              <button className="appt-card__action-btn" onClick={() => deleteEmployee(e.id)}><Trash2 size={15} /></button>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(ev) => ev.stopPropagation()}>
            <div className="modal__header">
              <h2>{editingId ? 'Editar Empleada' : 'Nueva Empleada'}</h2>
              <button className="modal__close" onClick={() => setShowModal(false)}><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="modal__form" id="employee-form">
              <div className="modal__row">
                <div className="modal__field"><label>Nombre Completo</label><input required value={form.name} onChange={(ev) => setForm({ ...form, name: ev.target.value })} /></div>
                <div className="modal__field"><label>Rol / Cargo</label><input required placeholder="Esteticista, Cosmetóloga..." value={form.role} onChange={(ev) => setForm({ ...form, role: ev.target.value })} /></div>
              </div>
              <div className="modal__row">
                <div className="modal__field"><label>Teléfono</label><input value={form.phone} onChange={(ev) => setForm({ ...form, phone: ev.target.value })} /></div>
                <div className="modal__field"><label>Email</label><input type="email" value={form.email || ''} onChange={(ev) => setForm({ ...form, email: ev.target.value })} /></div>
              </div>
              <div className="modal__row">
                <div className="modal__field"><label>% Comisión</label><input type="number" min={0} max={100} value={form.commissionPct} onChange={(ev) => setForm({ ...form, commissionPct: Number(ev.target.value) })} /></div>
                <div className="modal__field"><label>Horario</label><input placeholder="Lun-Vie 8:00-17:00" value={form.schedule} onChange={(ev) => setForm({ ...form, schedule: ev.target.value })} /></div>
              </div>
              <div className="modal__actions">
                <div style={{ flex: 1 }} />
                <button type="button" className="modal__cancel-btn" onClick={() => setShowModal(false)}>Cancelar</button>
                <button type="submit" className="modal__submit-btn" id="employee-submit">{editingId ? 'Guardar' : 'Crear'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
