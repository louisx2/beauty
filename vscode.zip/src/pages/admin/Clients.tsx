import { useState, useMemo, useEffect } from 'react';
import { useClientStore, type Client } from '../../store/clientStore';
import {
  Plus, Search, User, Phone, Mail, FileText,
  X, Edit2, Trash2, Heart, Shield, MessageCircle, ChevronRight,
} from 'lucide-react';
import './Clients.css';

const SKIN_TYPES = ['Normal', 'Seca', 'Grasa', 'Mixta', 'Sensible'];

const emptyForm = {
  name: '', cedula: '', phone: '', email: '', skin_type: '', allergies: '', notes: '', source: 'manual' as string,
};

export default function Clients() {
  const { clients, fetchClients, addClient, updateClient, deleteClient } = useClientStore();

  useEffect(() => { fetchClients(); }, [fetchClients]);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);

  const filtered = useMemo(() => {
    if (!search) return clients;
    const q = search.toLowerCase();
    return clients.filter(
      (c) => c.name.toLowerCase().includes(q) || c.phone.includes(q) || (c.cedula || '').includes(q) || (c.email || '').toLowerCase().includes(q)
    );
  }, [clients, search]);

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setShowModal(true);
  };

  const openEdit = (c: Client) => {
    setEditingId(c.id);
    setForm({ name: c.name, cedula: c.cedula || '', phone: c.phone, email: c.email || '', skin_type: c.skin_type || '', allergies: c.allergies || '', notes: c.notes || '', source: c.source });
    setShowModal(true);
    setSelectedClient(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) { await updateClient(editingId, form); }
    else { await addClient(form); }
    setShowModal(false);
  };

  const handleWhatsApp = (c: Client) => {
    const phone = c.phone.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/1${phone}?text=${encodeURIComponent(`Hola ${c.name}, te escribimos de Anadsll Beauty Esthetic.`)}`, '_blank');
  };

  const getAge = (birthDate: string) => {
    if (!birthDate) return '';
    const diff = Date.now() - new Date(birthDate).getTime();
    return String(Math.floor(diff / 31557600000)) + ' años';
  };

  return (
    <div className="clients">
      {/* Header */}
      <div className="clients__header">
        <div>
          <h1 className="clients__title">CRM de Clientas</h1>
          <p className="clients__subtitle">{clients.length} clientas registradas</p>
        </div>
        <button className="appts__add-btn" onClick={openCreate} id="btn-new-client">
          <Plus size={18} /> Nueva Clienta
        </button>
      </div>

      {/* Search */}
      <div className="clients__search-bar">
        <div className="appts__search" style={{ maxWidth: 400 }}>
          <Search size={16} />
          <input
            type="text"
            placeholder="Buscar por nombre, cédula, teléfono..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            id="clients-search"
          />
        </div>
      </div>

      <div className="clients__layout">
        {/* Client List */}
        <div className="clients__list">
          {filtered.length === 0 ? (
            <div className="appts__empty">
              <User size={40} />
              <p>No se encontraron clientas</p>
            </div>
          ) : (
            filtered.map((c) => (
              <div
                className={`client-row ${selectedClient?.id === c.id ? 'client-row--selected' : ''}`}
                key={c.id}
                onClick={() => setSelectedClient(c)}
              >
                <div className="client-row__avatar">
                  {c.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                </div>
                <div className="client-row__info">
                  <strong>{c.name}</strong>
                  <span><Phone size={12} /> {c.phone}</span>
                </div>
                <div className="client-row__meta">
                  <span className="client-row__skin">{c.skin_type || '—'}</span>
                  {c.allergies && <span className="client-row__allergy">⚠ Alergias</span>}
                </div>
                <ChevronRight size={16} className="client-row__chevron" />
              </div>
            ))
          )}
        </div>

        {/* Client Detail Panel */}
        {selectedClient ? (
          <div className="client-detail">
            <div className="client-detail__header">
              <div className="client-detail__avatar-lg">
                {selectedClient.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
              </div>
              <h2>{selectedClient.name}</h2>
              <span className="client-detail__since">Clienta desde {new Date(selectedClient.created_at).toLocaleDateString('es-DO', { month: 'long', year: 'numeric' })}</span>

              <div className="client-detail__actions">
                <button onClick={() => openEdit(selectedClient)} className="client-detail__btn"><Edit2 size={15} /> Editar</button>
                <button onClick={() => handleWhatsApp(selectedClient)} className="client-detail__btn client-detail__btn--wa"><MessageCircle size={15} /> WhatsApp</button>
                <button onClick={() => { deleteClient(selectedClient.id); setSelectedClient(null); }} className="client-detail__btn client-detail__btn--danger"><Trash2 size={15} /></button>
              </div>
            </div>

            <div className="client-detail__body">
              <div className="client-detail__section">
                <h4>Información Personal</h4>
                <div className="client-detail__grid">
                  <div className="client-detail__item">
                    <span className="client-detail__label"><Shield size={13} /> Cédula</span>
                    <span className="client-detail__value">{selectedClient.cedula || '—'}</span>
                  </div>
                  <div className="client-detail__item">
                    <span className="client-detail__label"><Phone size={13} /> Teléfono</span>
                    <span className="client-detail__value">{selectedClient.phone}</span>
                  </div>
                  <div className="client-detail__item">
                    <span className="client-detail__label"><Mail size={13} /> Email</span>
                    <span className="client-detail__value">{selectedClient.email || '—'}</span>
                  </div>
                </div>
              </div>

              <div className="client-detail__section">
                <h4>Información Clínica</h4>
                <div className="client-detail__grid">
                  <div className="client-detail__item">
                    <span className="client-detail__label"><Heart size={13} /> Tipo de Piel</span>
                    <span className="client-detail__value">{selectedClient.skin_type || '—'}</span>
                  </div>
                  <div className="client-detail__item">
                    <span className="client-detail__label">⚠️ Alergias</span>
                    <span className="client-detail__value" style={selectedClient.allergies ? { color: '#fbbf24' } : {}}>{selectedClient.allergies || 'Ninguna'}</span>
                  </div>
                </div>
              </div>

              {selectedClient.notes && (
                <div className="client-detail__section">
                  <h4>Notas</h4>
                  <p className="client-detail__notes-text"><FileText size={13} /> {selectedClient.notes}</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="client-detail client-detail--empty">
            <User size={48} />
            <p>Selecciona una clienta para ver su ficha</p>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal__header">
              <h2>{editingId ? 'Editar Clienta' : 'Nueva Clienta'}</h2>
              <button className="modal__close" onClick={() => setShowModal(false)}><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="modal__form" id="client-form">
              <div className="modal__row">
                <div className="modal__field">
                  <label><User size={14} /> Nombre Completo</label>
                  <input type="text" required placeholder="Nombre de la clienta" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div className="modal__field">
                  <label><Shield size={14} /> Cédula</label>
                  <input type="text" placeholder="001-0000000-0" value={form.cedula} onChange={(e) => setForm({ ...form, cedula: e.target.value })} />
                </div>
              </div>
              <div className="modal__row">
                <div className="modal__field">
                  <label><Phone size={14} /> Teléfono</label>
                  <input type="tel" required placeholder="829-000-0000" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                </div>
                <div className="modal__field">
                  <label><Mail size={14} /> Email</label>
                  <input type="email" placeholder="correo@email.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                </div>
              </div>
              <div className="modal__row">
                <div className="modal__field">
                  <label><Heart size={14} /> Tipo de Piel</label>
                  <select value={form.skin_type} onChange={(e) => setForm({ ...form, skin_type: e.target.value })}>
                    <option value="">Seleccionar</option>
                    {SKIN_TYPES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div className="modal__field">
                <label>⚠️ Alergias</label>
                <input type="text" placeholder="Retinol, fragancias, etc." value={form.allergies} onChange={(e) => setForm({ ...form, allergies: e.target.value })} />
              </div>
              <div className="modal__field">
                <label><FileText size={14} /> Notas</label>
                <textarea placeholder="Observaciones importantes..." rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </div>
              <div className="modal__actions">
                <div style={{ flex: 1 }} />
                <button type="button" className="modal__cancel-btn" onClick={() => setShowModal(false)}>Cancelar</button>
                <button type="submit" className="modal__submit-btn" id="client-submit">{editingId ? 'Guardar' : 'Crear Clienta'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
