import { useState, useEffect } from 'react';
import { useBillingStore } from '../../store/billingStore';
import { Save, Building2, FileText, Clock, CreditCard, Shield } from 'lucide-react';
import './Settings.css';

export default function SettingsPage() {
  const { ncfSequences, fetchAll } = useBillingStore();

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const [business, setBusiness] = useState({
    name: 'Anadsll Beauty Esthetic',
    rnc: '',
    address: 'C/Altagracia, #65, Pueblo Abajo',
    phone: '829-322-4014',
    email: 'info@anadsll.com',
    instagram: '@anadsllbeautyesthetic.rd',
  });

  const [schedule, setSchedule] = useState({
    monFri: '8:00 AM - 6:00 PM',
    saturday: '8:00 AM - 2:00 PM',
    sunday: 'Cerrado',
  });

  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="settings">
      <div className="clients__header">
        <div>
          <h1 className="clients__title">Configuración</h1>
          <p className="clients__subtitle">Datos del negocio, NCF y horarios</p>
        </div>
        <button className="appts__add-btn" onClick={handleSave} id="btn-save-settings">
          <Save size={18} /> {saved ? '¡Guardado!' : 'Guardar Cambios'}
        </button>
      </div>

      <div className="settings__grid">
        {/* Business Info */}
        <div className="settings__card">
          <h3><Building2 size={18} /> Datos del Negocio</h3>
          <div className="settings__fields">
            <div className="modal__field">
              <label>Nombre del Negocio</label>
              <input value={business.name} onChange={(e) => setBusiness({ ...business, name: e.target.value })} />
            </div>
            <div className="modal__field">
              <label><Shield size={14} /> RNC</label>
              <input placeholder="Ingresa el RNC del negocio" value={business.rnc} onChange={(e) => setBusiness({ ...business, rnc: e.target.value })} />
              <span className="settings__hint">Necesario para NCF tipo B01 (Crédito Fiscal)</span>
            </div>
            <div className="modal__field">
              <label>Dirección</label>
              <input value={business.address} onChange={(e) => setBusiness({ ...business, address: e.target.value })} />
            </div>
            <div className="modal__row">
              <div className="modal__field">
                <label>Teléfono</label>
                <input value={business.phone} onChange={(e) => setBusiness({ ...business, phone: e.target.value })} />
              </div>
              <div className="modal__field">
                <label>Email</label>
                <input value={business.email} onChange={(e) => setBusiness({ ...business, email: e.target.value })} />
              </div>
            </div>
            <div className="modal__field">
              <label>Instagram</label>
              <input value={business.instagram} onChange={(e) => setBusiness({ ...business, instagram: e.target.value })} />
            </div>
          </div>
        </div>

        {/* NCF Sequences */}
        <div className="settings__card">
          <h3><FileText size={18} /> Secuencias NCF</h3>
          <p className="settings__card-desc">Secuencias autorizadas por DGII. Actualiza los rangos según tus autorizaciones.</p>
          <div className="settings__ncf-list">
            {ncfSequences.map((seq) => (
              <div className="settings__ncf-row" key={seq.type}>
                <div className="settings__ncf-type">
                  <strong>{seq.type}</strong>
                  <span>{seq.prefix}...</span>
                </div>
                <div className="settings__ncf-info">
                  <div>
                    <span>Actual</span>
                    <strong>{seq.currentNumber}</strong>
                  </div>
                  <div>
                    <span>Rango</span>
                    <strong>{seq.rangeStart} - {seq.rangeEnd}</strong>
                  </div>
                  <div>
                    <span>Restantes</span>
                    <strong className={seq.rangeEnd - seq.currentNumber < 50 ? 'settings__ncf-low' : ''}>
                      {seq.rangeEnd - seq.currentNumber}
                    </strong>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Schedule */}
        <div className="settings__card">
          <h3><Clock size={18} /> Horario de Atención</h3>
          <div className="settings__fields">
            <div className="modal__field">
              <label>Lunes a Viernes</label>
              <input value={schedule.monFri} onChange={(e) => setSchedule({ ...schedule, monFri: e.target.value })} />
            </div>
            <div className="modal__field">
              <label>Sábado</label>
              <input value={schedule.saturday} onChange={(e) => setSchedule({ ...schedule, saturday: e.target.value })} />
            </div>
            <div className="modal__field">
              <label>Domingo</label>
              <input value={schedule.sunday} onChange={(e) => setSchedule({ ...schedule, sunday: e.target.value })} />
            </div>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="settings__card">
          <h3><CreditCard size={18} /> Métodos de Pago</h3>
          <div className="settings__payments">
            {['Efectivo', 'Tarjeta de Crédito/Débito', 'Transferencia Bancaria', 'Pago Mixto'].map((m) => (
              <div className="settings__payment-item" key={m}>
                <label className="toggle-switch">
                  <input type="checkbox" defaultChecked />
                  <span className="toggle-slider" />
                </label>
                <span>{m}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
