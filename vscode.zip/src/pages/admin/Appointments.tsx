import { useState, useMemo, useEffect } from 'react';
import {
  useAppointmentStore,
  type Appointment,
  type AppointmentStatus,
} from '../../store/appointmentStore';
import {
  Plus,
  Search,
  ChevronLeft,
  ChevronRight,
  Clock,
  Phone,
  MessageCircle,
  X,
  Filter,
  User,
  Calendar,
  Sparkles,
  FileText,
  CheckCircle2,
  XCircle,
  AlertCircle,
  PlayCircle,
  Ban,
  Edit2,
  CalendarClock,
  Trash2,
} from 'lucide-react';
import './Appointments.css';

const STATUS_CONFIG: Record<AppointmentStatus, { label: string; class: string; icon: React.ReactNode }> = {
  pending: { label: 'Pendiente', class: 'badge--amber', icon: <AlertCircle size={14} /> },
  confirmed: { label: 'Confirmada', class: 'badge--green', icon: <CheckCircle2 size={14} /> },
  in_progress: { label: 'En Proceso', class: 'badge--blue', icon: <PlayCircle size={14} /> },
  completed: { label: 'Completada', class: 'badge--emerald', icon: <CheckCircle2 size={14} /> },
  cancelled: { label: 'Cancelada', class: 'badge--red', icon: <XCircle size={14} /> },
  no_show: { label: 'No Asistió', class: 'badge--gray', icon: <Ban size={14} /> },
};

const STATUS_TRANSITIONS: Record<AppointmentStatus, AppointmentStatus[]> = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['in_progress', 'cancelled', 'no_show'],
  in_progress: ['completed'],
  completed: [],
  cancelled: [],
  no_show: [],
};

const SERVICE_OPTIONS = [
  'Depilación Láser - Piernas',
  'Depilación Láser - Axilas',
  'Depilación Láser - Bikini',
  'Depilación Láser - Rostro',
  'Limpieza Facial',
  'Limpieza Profunda',
  'Cuidado Facial Premium',
  'Rejuvenecimiento Facial',
  'Tratamiento Corporal Reductivo',
  'Belleza Integral',
  'Maquillaje Profesional',
  'Drenaje Linfático',
];

const EMPLOYEES = ['Dra. Ana', 'Carmen'];

const HOURS = Array.from({ length: 11 }, (_, i) => {
  const h = i + 8;
  return `${String(h).padStart(2, '0')}:00`;
}).flatMap((h) => [h, h.replace(':00', ':30')]);

function formatDate(dateStr: string): string {
  const d = new Date(dateStr + 'T12:00:00');
  return d.toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

function getToday(): string {
  return new Date().toISOString().split('T')[0];
}

function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + 'T12:00:00');
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

function getWeekDates(dateStr: string): string[] {
  const d = new Date(dateStr + 'T12:00:00');
  const day = d.getDay();
  const monday = new Date(d);
  monday.setDate(d.getDate() - (day === 0 ? 6 : day - 1));
  return Array.from({ length: 7 }, (_, i) => {
    const dt = new Date(monday);
    dt.setDate(monday.getDate() + i);
    return dt.toISOString().split('T')[0];
  });
}

const emptyForm: Omit<Appointment, 'id' | 'createdAt'> = {
  client_id: null,
  clientName: '',
  clientPhone: '',
  service: '',
  employee: '',
  date: getToday(),
  time: '09:00',
  duration: 45,
  status: 'pending',
  notes: '',
  source: 'manual',
};

export default function Appointments() {
  const { 
    appointments, 
    fetchAppointments,
    addAppointment, 
    updateAppointment, 
    updateStatus, 
    deleteAppointment,
    autoMarkNoShow 
  } = useAppointmentStore();

  useEffect(() => {
    fetchAppointments().then(() => autoMarkNoShow());
  }, [fetchAppointments, autoMarkNoShow]);

  const [selectedDate, setSelectedDate] = useState(getToday());
  const [view, setView] = useState<'day' | 'week'>('day');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterEmployee, setFilterEmployee] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [showStatusMenu, setShowStatusMenu] = useState<string | null>(null);

  // Filtered appointments
  const filteredAppointments = useMemo(() => {
    let list: Appointment[];

    if (view === 'day') {
      list = appointments.filter((a) => a.date === selectedDate);
    } else {
      const weekDates = getWeekDates(selectedDate);
      list = appointments.filter((a) => weekDates.includes(a.date));
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (a) =>
          a.clientName.toLowerCase().includes(q) ||
          a.service.toLowerCase().includes(q) ||
          a.clientPhone.includes(q)
      );
    }
    if (filterEmployee) {
      list = list.filter((a) => a.employee === filterEmployee);
    }
    if (filterStatus) {
      list = list.filter((a) => a.status === filterStatus);
    }

    return list.sort((a, b) => {
      if (a.date !== b.date) return a.date.localeCompare(b.date);
      return a.time.localeCompare(b.time);
    });
  }, [appointments, selectedDate, view, searchQuery, filterEmployee, filterStatus]);

  // Week dates for week view
  const weekDates = useMemo(() => getWeekDates(selectedDate), [selectedDate]);

  // Stats for selected date
  const dayStats = useMemo(() => {
    const dayAppts = appointments.filter((a) => a.date === selectedDate);
    return {
      total: dayAppts.length,
      confirmed: dayAppts.filter((a) => a.status === 'confirmed').length,
      pending: dayAppts.filter((a) => a.status === 'pending').length,
      completed: dayAppts.filter((a) => a.status === 'completed').length,
    };
  }, [appointments, selectedDate]);

  const openCreate = () => {
    setEditingId(null);
    setForm({ ...emptyForm, date: selectedDate });
    setShowModal(true);
  };

  const openEdit = (appt: Appointment) => {
    setEditingId(appt.id);
    setForm({
      client_id: appt.client_id || null,
      clientName: appt.clientName,
      clientPhone: appt.clientPhone,
      service: appt.service,
      employee: appt.employee,
      date: appt.date,
      time: appt.time,
      duration: appt.duration,
      status: appt.status,
      notes: appt.notes,
      source: appt.source,
    });
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      updateAppointment(editingId, form);
    } else {
      addAppointment(form);
    }
    setShowModal(false);
  };

  const handleWhatsApp = (appt: Appointment) => {
    const phone = appt.clientPhone.replace(/[^0-9]/g, '');
    const msg = `Hola ${appt.clientName}, le recordamos su cita:\n\n📅 Fecha: ${formatDate(appt.date)}\n🕐 Hora: ${appt.time}\n💆 Servicio: ${appt.service}\n\n¡La esperamos en Anadsll Beauty Esthetic!`;
    window.open(`https://wa.me/1${phone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handleReschedule = (appt: Appointment) => {
    setEditingId(appt.id);
    setForm({
      client_id: appt.client_id || null,
      clientName: appt.clientName,
      clientPhone: appt.clientPhone,
      service: appt.service,
      employee: appt.employee,
      date: appt.date,
      time: appt.time,
      duration: appt.duration,
      status: appt.status,
      notes: appt.notes,
      source: appt.source,
    });
    setShowModal(true);
  };

  const handleCancel = (appt: Appointment) => {
    if (appt.status === 'cancelled' || appt.status === 'completed') return;
    updateStatus(appt.id, 'cancelled');
  };

  return (
    <div className="appts">
      {/* Header */}
      <div className="appts__header">
        <div>
          <h1 className="appts__title">Gestión de Citas</h1>
          <p className="appts__subtitle">Agenda y administra todas las citas del salón</p>
        </div>
        <button className="appts__add-btn" onClick={openCreate} id="btn-new-appointment">
          <Plus size={18} /> Nueva Cita
        </button>
      </div>

      {/* Date Navigation + View Toggle */}
      <div className="appts__controls">
        <div className="appts__date-nav">
          <button onClick={() => setSelectedDate(addDays(selectedDate, view === 'day' ? -1 : -7))} className="appts__nav-btn">
            <ChevronLeft size={18} />
          </button>
          <button onClick={() => setSelectedDate(getToday())} className="appts__today-btn">Hoy</button>
          <button onClick={() => setSelectedDate(addDays(selectedDate, view === 'day' ? 1 : 7))} className="appts__nav-btn">
            <ChevronRight size={18} />
          </button>
          <span className="appts__current-date">{formatDate(selectedDate)}</span>
        </div>

        <div className="appts__view-toggle">
          <button className={`appts__view-btn ${view === 'day' ? 'appts__view-btn--active' : ''}`} onClick={() => setView('day')}>Día</button>
          <button className={`appts__view-btn ${view === 'week' ? 'appts__view-btn--active' : ''}`} onClick={() => setView('week')}>Semana</button>
        </div>
      </div>

      {/* Day Stats */}
      {view === 'day' && (
        <div className="appts__day-stats">
          <div className="appts__mini-stat">
            <span className="appts__mini-stat-val">{dayStats.total}</span>
            <span>Total</span>
          </div>
          <div className="appts__mini-stat appts__mini-stat--green">
            <span className="appts__mini-stat-val">{dayStats.confirmed}</span>
            <span>Confirmadas</span>
          </div>
          <div className="appts__mini-stat appts__mini-stat--amber">
            <span className="appts__mini-stat-val">{dayStats.pending}</span>
            <span>Pendientes</span>
          </div>
          <div className="appts__mini-stat appts__mini-stat--emerald">
            <span className="appts__mini-stat-val">{dayStats.completed}</span>
            <span>Completadas</span>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="appts__filters">
        <div className="appts__search">
          <Search size={16} />
          <input
            type="text"
            placeholder="Buscar clienta, servicio..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            id="appts-search"
          />
        </div>
        <div className="appts__filter-group">
          <Filter size={16} />
          <select value={filterEmployee} onChange={(e) => setFilterEmployee(e.target.value)} id="filter-employee">
            <option value="">Todas las empleadas</option>
            {EMPLOYEES.map((emp) => <option key={emp} value={emp}>{emp}</option>)}
          </select>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} id="filter-status">
            <option value="">Todos los estados</option>
            {Object.entries(STATUS_CONFIG).map(([key, val]) => (
              <option key={key} value={key}>{val.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Week View Header */}
      {view === 'week' && (
        <div className="appts__week-header">
          {weekDates.map((d) => {
            const dt = new Date(d + 'T12:00:00');
            const isToday = d === getToday();
            const count = appointments.filter((a) => a.date === d).length;
            return (
              <button
                key={d}
                className={`appts__week-day ${d === selectedDate ? 'appts__week-day--selected' : ''} ${isToday ? 'appts__week-day--today' : ''}`}
                onClick={() => { setSelectedDate(d); setView('day'); }}
              >
                <span className="appts__week-day-name">{dt.toLocaleDateString('es-DO', { weekday: 'short' })}</span>
                <span className="appts__week-day-num">{dt.getDate()}</span>
                {count > 0 && <span className="appts__week-day-count">{count}</span>}
              </button>
            );
          })}
        </div>
      )}

      {/* Appointment List */}
      <div className="appts__list">
        {filteredAppointments.length === 0 ? (
          <div className="appts__empty">
            <Calendar size={40} />
            <p>No hay citas {view === 'day' ? 'para este día' : 'esta semana'}</p>
          </div>
        ) : (
          filteredAppointments.map((appt) => (
            <div className={`appt-card appt-card--${appt.status}`} key={appt.id}>
              <div className="appt-card__time-col">
                <span className="appt-card__time">{appt.time}</span>
                <span className="appt-card__duration"><Clock size={12} /> {appt.duration} min</span>
              </div>

              <div className="appt-card__body" onClick={() => openEdit(appt)}>
                <div className="appt-card__top">
                  <h4 className="appt-card__client">{appt.clientName}</h4>
                  <div className="appt-card__status-wrap" style={{ position: 'relative' }}>
                    <button
                      className={`badge ${STATUS_CONFIG[appt.status].class}`}
                      onClick={(e) => { e.stopPropagation(); setShowStatusMenu(showStatusMenu === appt.id ? null : appt.id); }}
                      id={`status-btn-${appt.id}`}
                    >
                      {STATUS_CONFIG[appt.status].icon}
                      {STATUS_CONFIG[appt.status].label}
                    </button>

                    {showStatusMenu === appt.id && STATUS_TRANSITIONS[appt.status].length > 0 && (
                      <div className="appt-card__status-menu" onClick={(e) => e.stopPropagation()}>
                        {STATUS_TRANSITIONS[appt.status].map((s) => (
                          <button
                            key={s}
                            className="appt-card__status-option"
                            onClick={() => { updateStatus(appt.id, s); setShowStatusMenu(null); }}
                          >
                            {STATUS_CONFIG[s].icon}
                            {STATUS_CONFIG[s].label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="appt-card__details">
                  <span><Sparkles size={13} /> {appt.service}</span>
                  <span><User size={13} /> {appt.employee}</span>
                  {view === 'week' && <span><Calendar size={13} /> {new Date(appt.date + 'T12:00:00').toLocaleDateString('es-DO', { weekday: 'short', day: 'numeric' })}</span>}
                </div>

                {appt.notes && (
                  <div className="appt-card__notes">
                    <FileText size={12} /> {appt.notes}
                  </div>
                )}
              </div>

              <div className="appt-card__actions">
                <button
                  className="appt-card__action-btn appt-card__action-btn--wa"
                  onClick={(e) => { e.stopPropagation(); handleWhatsApp(appt); }}
                  title="Enviar recordatorio por WhatsApp"
                >
                  <MessageCircle size={16} />
                </button>
                <a
                  href={`tel:${appt.clientPhone}`}
                  className="appt-card__action-btn"
                  onClick={(e) => e.stopPropagation()}
                  title="Llamar"
                >
                  <Phone size={16} />
                </a>
                {appt.status === 'confirmed' && (
                  <>
                    <button
                      className="appt-card__action-btn appt-card__action-btn--success"
                      onClick={(e) => { e.stopPropagation(); updateStatus(appt.id, 'in_progress'); }}
                      title="Llegó / Iniciar"
                    >
                      <CheckCircle2 size={16} />
                    </button>
                    <button
                      className="appt-card__action-btn appt-card__action-btn--danger"
                      onClick={(e) => { e.stopPropagation(); updateStatus(appt.id, 'no_show'); }}
                      title="No Asistió"
                    >
                      <Ban size={16} />
                    </button>
                  </>
                )}
                {appt.status !== 'completed' && appt.status !== 'cancelled' && (
                  <>
                    <button
                      className="appt-card__action-btn appt-card__action-btn--reschedule"
                      onClick={(e) => { e.stopPropagation(); handleReschedule(appt); }}
                      title="Mover / Reprogramar"
                    >
                      <CalendarClock size={16} />
                    </button>
                    <button
                      className="appt-card__action-btn appt-card__action-btn--cancel"
                      onClick={(e) => { e.stopPropagation(); handleCancel(appt); }}
                      title="Cancelar Cita"
                    >
                      <XCircle size={16} />
                    </button>
                  </>
                )}
                <button
                  className="appt-card__action-btn"
                  onClick={(e) => { e.stopPropagation(); openEdit(appt); }}
                  title="Editar"
                >
                  <Edit2 size={16} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal: Create/Edit */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal__header">
              <h2>{editingId ? 'Editar Cita' : 'Nueva Cita'}</h2>
              <button className="modal__close" onClick={() => setShowModal(false)}><X size={20} /></button>
            </div>

            <form onSubmit={handleSubmit} className="modal__form" id="appointment-form">
              <div className="modal__row">
                <div className="modal__field">
                  <label><User size={14} /> Nombre de la Clienta</label>
                  <input
                    type="text"
                    required
                    placeholder="Nombre completo"
                    value={form.clientName}
                    onChange={(e) => setForm({ ...form, clientName: e.target.value })}
                  />
                </div>
                <div className="modal__field">
                  <label><Phone size={14} /> Teléfono</label>
                  <input
                    type="tel"
                    required
                    placeholder="829-000-0000"
                    value={form.clientPhone}
                    onChange={(e) => setForm({ ...form, clientPhone: e.target.value })}
                  />
                </div>
              </div>

              <div className="modal__field">
                <label><Sparkles size={14} /> Servicio</label>
                <select required value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })}>
                  <option value="">Seleccionar servicio</option>
                  {SERVICE_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div className="modal__field">
                <label><User size={14} /> Empleada</label>
                <select required value={form.employee} onChange={(e) => setForm({ ...form, employee: e.target.value })}>
                  <option value="">Seleccionar empleada</option>
                  {EMPLOYEES.map((e) => <option key={e} value={e}>{e}</option>)}
                </select>
              </div>

              <div className="modal__row">
                <div className="modal__field">
                  <label><Calendar size={14} /> Fecha</label>
                  <input type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
                </div>
                <div className="modal__field">
                  <label><Clock size={14} /> Hora</label>
                  <select required value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })}>
                    {HOURS.map((h) => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>
                <div className="modal__field">
                  <label><Clock size={14} /> Duración</label>
                  <select value={form.duration} onChange={(e) => setForm({ ...form, duration: Number(e.target.value) })}>
                    <option value={30}>30 min</option>
                    <option value={45}>45 min</option>
                    <option value={60}>60 min</option>
                    <option value={90}>90 min</option>
                    <option value={120}>120 min</option>
                  </select>
                </div>
              </div>

              <div className="modal__field">
                <label><FileText size={14} /> Notas</label>
                <textarea
                  placeholder="Observaciones, alergias, sesión #..."
                  rows={3}
                  value={form.notes || ''}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                />
              </div>

              <div className="modal__actions">
                {editingId && (
                  <button
                    type="button"
                    className="modal__delete-btn"
                    onClick={() => { deleteAppointment(editingId); setShowModal(false); }}
                  >
                    Eliminar Cita
                  </button>
                )}
                <div style={{ flex: 1 }} />
                <button type="button" className="modal__cancel-btn" onClick={() => setShowModal(false)}>Cancelar</button>
                <button type="submit" className="modal__submit-btn" id="appointment-submit">
                  {editingId ? 'Guardar Cambios' : 'Crear Cita'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
