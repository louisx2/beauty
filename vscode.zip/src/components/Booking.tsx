import { useState, useEffect } from 'react';
import { Calendar, Clock, User, Phone, MessageCircle, Send } from 'lucide-react';
import { supabase } from '../lib/supabase';
import './Booking.css';

const fallbackServices = [
  'Depilación Láser', 'Limpieza Profunda', 'Cuidado Facial',
  'Belleza Integral', 'Tratamiento Corporal', 'Rejuvenecimiento',
];

export default function Booking() {
  const [serviceNames, setServiceNames] = useState<string[]>(fallbackServices);
  const [form, setForm] = useState({
    name: '', phone: '', service: '', date: '', time: '', notes: '',
  });
  const [sending, setSending] = useState(false);

  useEffect(() => {
    supabase.from('services').select('name').eq('active', true).order('name').then(({ data }) => {
      if (data && data.length > 0) setServiceNames(data.map((s: any) => s.name));
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);

    // Save to Supabase
    await supabase.from('appointments').insert({
      client_name: form.name,
      client_phone: form.phone,
      service: form.service,
      employee: 'Por asignar',
      date: form.date,
      time: form.time,
      duration: 60,
      status: 'pending',
      notes: form.notes || '',
      source: 'web',
    });

    // Also send to WhatsApp
    const msg = `Hola, quiero agendar una cita:\n\n` +
      `👤 Nombre: ${form.name}\n` +
      `📞 Teléfono: ${form.phone}\n` +
      `💆 Servicio: ${form.service}\n` +
      `📅 Fecha: ${form.date}\n` +
      `🕐 Hora: ${form.time}\n` +
      `📝 Notas: ${form.notes || 'Ninguna'}`;
    window.open(`https://wa.me/18293224014?text=${encodeURIComponent(msg)}`, '_blank');
    setSending(false);
  };

  return (
    <section className="booking" id="agendar">
      <div className="booking__inner">
        <div className="booking__info">
          <span className="section-tag">Agendar Cita</span>
          <h2 className="booking__title">
            Reserva tu <span className="gradient-text">cita</span> ahora
          </h2>
          <p className="booking__text">
            Completa el formulario y te redirigiremos a WhatsApp para confirmar tu cita
            con nuestro equipo. ¡Es rápido y sencillo!
          </p>

          <div className="booking__benefits">
            <div className="booking__benefit">
              <Calendar size={20} />
              <span>Agenda en menos de 1 minuto</span>
            </div>
            <div className="booking__benefit">
              <MessageCircle size={20} />
              <span>Confirmación por WhatsApp</span>
            </div>
            <div className="booking__benefit">
              <Clock size={20} />
              <span>Horario: Lun - Sáb, 9am - 7pm</span>
            </div>
          </div>
        </div>

        <form className="booking__form glass" onSubmit={handleSubmit} id="booking-form">
          <div className="booking__field">
            <label htmlFor="booking-name"><User size={16} /> Nombre Completo</label>
            <input
              type="text"
              id="booking-name"
              placeholder="Tu nombre completo"
              required
              value={form.name}
              onChange={e => setForm({...form, name: e.target.value})}
            />
          </div>

          <div className="booking__field">
            <label htmlFor="booking-phone"><Phone size={16} /> Teléfono</label>
            <input
              type="tel"
              id="booking-phone"
              placeholder="829-000-0000"
              required
              value={form.phone}
              onChange={e => setForm({...form, phone: e.target.value})}
            />
          </div>

          <div className="booking__field">
            <label htmlFor="booking-service">💆 Servicio</label>
            <select
              id="booking-service"
              required
              value={form.service}
              onChange={e => setForm({...form, service: e.target.value})}
            >
              <option value="">Selecciona un servicio</option>
              {serviceNames.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          <div className="booking__row">
            <div className="booking__field">
              <label htmlFor="booking-date"><Calendar size={16} /> Fecha</label>
              <input
                type="date"
                id="booking-date"
                required
                value={form.date}
                onChange={e => setForm({...form, date: e.target.value})}
              />
            </div>
            <div className="booking__field">
              <label htmlFor="booking-time"><Clock size={16} /> Hora</label>
              <input
                type="time"
                id="booking-time"
                required
                value={form.time}
                onChange={e => setForm({...form, time: e.target.value})}
              />
            </div>
          </div>

          <div className="booking__field">
            <label htmlFor="booking-notes">📝 Notas adicionales</label>
            <textarea
              id="booking-notes"
              placeholder="Algo que debamos saber..."
              rows={3}
              value={form.notes}
              onChange={e => setForm({...form, notes: e.target.value})}
            />
          </div>

          <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }} id="booking-submit" disabled={sending}>
            <Send size={16} />
            {sending ? 'Enviando...' : 'Enviar por WhatsApp'}
          </button>
        </form>
      </div>
    </section>
  );
}
