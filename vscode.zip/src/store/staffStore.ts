import { create } from 'zustand';
import { supabase } from '../lib/supabase';

export interface Employee {
  id: string;
  name: string;
  role: string;
  phone: string;
  email: string | null;
  commissionPct: number;
  schedule: string;
  active: boolean;
}

function mapRow(r: any): Employee {
  return {
    id: r.id, name: r.name, role: r.role, phone: r.phone,
    email: r.email, commissionPct: Number(r.commission_pct),
    schedule: r.schedule, active: r.active,
  };
}

interface StaffState {
  employees: Employee[];
  loading: boolean;
  fetchStaff: () => Promise<void>;
  addEmployee: (e: Omit<Employee, 'id'>) => Promise<void>;
  updateEmployee: (id: string, data: Partial<Employee>) => Promise<void>;
  deleteEmployee: (id: string) => Promise<void>;
}

export const useStaffStore = create<StaffState>()((set) => ({
  employees: [],
  loading: false,

  fetchStaff: async () => {
    set({ loading: true });
    const { data, error } = await supabase.from('staff').select('*').order('name');
    if (!error && data) set({ employees: data.map(mapRow), loading: false });
    else set({ loading: false });
  },

  addEmployee: async (e) => {
    const { data, error } = await supabase.from('staff').insert({
      name: e.name, role: e.role, phone: e.phone, email: e.email,
      commission_pct: e.commissionPct, schedule: e.schedule, active: e.active,
    }).select().single();
    if (!error && data) set((s) => ({ employees: [...s.employees, mapRow(data)] }));
  },

  updateEmployee: async (id, updates) => {
    const db: any = {};
    if (updates.name !== undefined) db.name = updates.name;
    if (updates.role !== undefined) db.role = updates.role;
    if (updates.phone !== undefined) db.phone = updates.phone;
    if (updates.email !== undefined) db.email = updates.email;
    if (updates.commissionPct !== undefined) db.commission_pct = updates.commissionPct;
    if (updates.schedule !== undefined) db.schedule = updates.schedule;
    if (updates.active !== undefined) db.active = updates.active;

    const { data, error } = await supabase.from('staff').update(db).eq('id', id).select().single();
    if (!error && data) set((s) => ({ employees: s.employees.map((e) => e.id === id ? mapRow(data) : e) }));
  },

  deleteEmployee: async (id) => {
    const { error } = await supabase.from('staff').delete().eq('id', id);
    if (!error) set((s) => ({ employees: s.employees.filter((e) => e.id !== id) }));
  },
}));
