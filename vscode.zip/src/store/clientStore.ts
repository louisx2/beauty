import { create } from 'zustand';
import { supabase } from '../lib/supabase';

export interface Client {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  cedula: string | null;
  skin_type: string | null;
  allergies: string | null;
  notes: string | null;
  source: string;
  created_at: string;
}

interface ClientState {
  clients: Client[];
  loading: boolean;
  error: string | null;
  fetchClients: () => Promise<void>;
  addClient: (c: Omit<Client, 'id' | 'created_at'>) => Promise<void>;
  updateClient: (id: string, data: Partial<Client>) => Promise<void>;
  deleteClient: (id: string) => Promise<void>;
}

export const useClientStore = create<ClientState>()((set, get) => ({
  clients: [],
  loading: false,
  error: null,

  fetchClients: async () => {
    set({ loading: true });
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) {
      set({ error: error.message, loading: false });
    } else {
      set({ clients: data || [], loading: false });
    }
  },

  addClient: async (c) => {
    const { data, error } = await supabase
      .from('clients')
      .insert(c)
      .select()
      .single();
    if (!error && data) {
      set((s) => ({ clients: [data, ...s.clients] }));
    }
  },

  updateClient: async (id, updates) => {
    const { data, error } = await supabase
      .from('clients')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    if (!error && data) {
      set((s) => ({
        clients: s.clients.map((c) => (c.id === id ? data : c)),
      }));
    }
  },

  deleteClient: async (id) => {
    const { error } = await supabase.from('clients').delete().eq('id', id);
    if (!error) {
      set((s) => ({ clients: s.clients.filter((c) => c.id !== id) }));
    }
  },
}));
