import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect } from 'react';
import { useAuthStore } from './store/authStore';
import LandingPage from './pages/LandingPage';
import Login from './pages/Login';
import AdminLayout from './pages/AdminLayout';
import ProtectedRoute from './components/ProtectedRoute';
import Dashboard from './pages/admin/Dashboard';
import Appointments from './pages/admin/Appointments';
import Clients from './pages/admin/Clients';
import Services from './pages/admin/Services';
import SessionPackages from './pages/admin/SessionPackages';
import Billing from './pages/admin/Billing';
import Inventory from './pages/admin/Inventory';
import Staff from './pages/admin/Staff';
import Reports from './pages/admin/Reports';
import SettingsPage from './pages/admin/Settings';

export default function App() {
  const checkSession = useAuthStore((s) => s.checkSession);
  const loading = useAuthStore((s) => s.loading);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: '#2A1F1A' }}>
        <div className="login__spinner" style={{ width: 40, height: 40 }} />
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* Public: Landing Page */}
        <Route path="/" element={<LandingPage />} />

        {/* Admin: Login */}
        <Route path="/admin/login" element={<Login />} />

        {/* Admin: Protected Routes */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="citas" element={<Appointments />} />
          <Route path="clientes" element={<Clients />} />
          <Route path="servicios" element={<Services />} />
          <Route path="paquetes" element={<SessionPackages />} />
          <Route path="facturacion" element={<Billing />} />
          <Route path="inventario" element={<Inventory />} />
          <Route path="empleadas" element={<Staff />} />
          <Route path="reportes" element={<Reports />} />
          <Route path="config" element={<SettingsPage />} />
        </Route>

        {/* Catch-all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
